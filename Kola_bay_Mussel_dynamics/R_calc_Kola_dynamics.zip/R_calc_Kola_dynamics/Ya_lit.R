library(readxl)
library(dplyr)
library(reshape2)
library(broom)
library(ggplot2)


Ya <- read_excel("Data/Ya_lit_initial_data.xlsx")

str(Ya)

unique(Ya$Frame_area)

# делаем матрицу с количеством изученных мидий
Ya_count <- dcast(Year + Sample + Part_studied + Frame_area + Include ~ Age, data = Ya)



# делаем матрицу численностей на квадратный метр
Ya_count[ , 6 : ncol(Ya_count)] <- Ya_count[ , 6 : ncol(Ya_count)] / Ya_count$Part_studied / Ya_count$Frame_area

# убираем мидий из 2002 года
Ya_count <- Ya_count %>% 
  filter(Include == 1)

Ya_count[Ya_count$Year == 2002 & Ya_count$Sample %in% c(2, 4), 6 : 8] <- NA

Ya_count[Ya_count$Year == 2002 & Ya_count$Sample %in% c(3, 5), 10 : 12] <- NA


Ya_count <- 
Ya_count %>% 
  group_by(Year, Sample) %>% 
  summarise_at(vars(- c(Part_studied,  Frame_area, Include)),.funs = sum)



# возвращаемся к "длинному" построчному формату
Ya_N <- melt(Ya_count, id.vars = c("Year", "Sample"), variable.name = "Age", value.name = "N") 

str(Ya_N)



# добавляем столбик с генерацией
Ya_N <- 
  Ya_N %>% 
  mutate(Generation = Year - as.numeric(Age))

# считаем среднюю численность каждогенерации для каждого года

Ya_gen <- 
  Ya_N %>% 
  group_by(Year, Generation, Age) %>% 
  summarise(mean_N = mean(N, na.rm = TRUE))
  # write.table("clipboard", sep = "\t")

  
# round(dcast(Generation ~ Year, data = Ya_gen))
  


Ya_gen %>% 
  filter(mean_N > 0) %>%
  filter(Generation >= 1995 & Generation <= 2014) %>% 
  mutate(Age = as.numeric(Age)) -> df


# 
# df %>% 
#   filter(Generation == 2014)
# 


df_sample_size <- 
  df %>%  
  group_by(Generation) %>% 
  summarise(N = n())


  df %>% 
  merge(., df_sample_size) %>% 
  group_by(Generation) %>% 
  filter(Age>1) %>% #
  filter(N > 3) %>% 
  group_modify( ~ tidy(lm(log(mean_N + 1) ~ Age, data = .))) -> df_lm_filtered
  
  
  df_lm_filtered %>%
    filter(term == "(Intercept)") %>% 
    select(Generation, estimate) %>% 
    mutate(Anundance_0 = exp(estimate)) -> 
    recruitment


###### Данные по климатическим параметрам
  clim <- read_excel("Data/climate_Murman.xlsx", sheet = "data_transposed", na = "NA")
    
clim_long <- 
  melt(clim, id.vars = c("Param",	"Param_Type",	"Month"), variable.name = "Year") %>% 
  filter(complete.cases(.)) %>% 
  mutate(Year = as.numeric(as.character(Year)))

clim_long <- 
  clim_long %>% 
  filter(Param_Type != "Sal_mean")

clim_long <- 
  clim_long %>% 
  mutate(Season = case_when(Month %in% 7:8 ~ "Summer",
                            Month %in% 9:11 ~ "Autumn",
                            Month %in% c(1:4) ~ "Winter",
                            Month %in% 5:6 ~ "Spring")) %>% 
  filter(complete.cases(.))

# лето июль-август
# Осень сентябрь-ноябрь
# зима декабрь-апрель
# весна май-июнь



# Динамика среднегоовых значений параметров  
clim_long %>% 
  group_by(Year, Param_Type) %>% 
  summarise(Mean_value = mean(value, na.rm = T)) %>% 
  ggplot(., aes(x= Year, y =  Mean_value)) +
  geom_line() +
  facet_wrap(~Param_Type, scales = "free_y")

  
## Подбираем оптимальную модель методом BioEnv

library(vegan)

clim_long %>% 
  group_by(Year, Season, Param_Type) %>% 
  summarise(Mean_value = mean(value, na.rm = T)) %>% 
  dcast(Year ~ Param_Type + Season) ->
  predictors

  
predictors %>% 
  filter(Year %in% recruitment$Generation) ->
  predictors_reduced

predictors_reduced <- 
  predictors_reduced %>% 
  select(-c(Tw_KM_Autumn, Tw_KM_Spring, Tw_KM_Summer, Tw_KM_Winter))

  


recruitment_dist <- vegdist(recruitment[,2], method = "euclidean")

bioenv_results <- bioenv(recruitment_dist, predictors_reduced[, -1],  metric = "euclidean")



### Визуализация связи с предикторами из оптимальной модели     

recruitment2 <- data.frame(Year = recruitment$Generation, variable = "Recruitment", value = recruitment$Anundance_0)

predictors_reduced %>% 
  select(Year, Ta_mean_Spring, Tw_mean_Spring, Wind_mean_Spring) %>% melt(., id.vars = "Year") %>% rbind(., recruitment2) %>% 
  ggplot(., aes(x = Year, y = value)) +
  geom_line() +
  facet_wrap(~variable, scales = "free_y") 


predictors_reduced %>% 
  select(Year, Ta_mean_Spring, Tw_mean_Spring, Wind_mean_Spring) %>% melt(., id.vars = "Year") %>%
  rbind(., recruitment2) %>% 
  dcast(Year ~ variable) %>%  
  ggplot(., aes(x = Tw_mean_Spring, y = log(Recruitment))) +
  geom_text(aes(label = Year))

predictors_reduced %>% 
  select(Year, Ta_mean_Spring, Tw_mean_Spring, Wind_mean_Spring) %>% melt(., id.vars = "Year") %>%
  rbind(., recruitment2) %>% 
  dcast(Year ~ variable) %>%  
  ggplot(., aes(x = Ta_mean_Spring, y = log(Recruitment))) +
  geom_text(aes(label = Year))
  


predictors_reduced %>% 
  select(Year, Ta_mean_Spring, Tw_mean_Spring, Wind_mean_Spring) %>% melt(., id.vars = "Year") %>%
  rbind(., recruitment2) %>% 
  dcast(Year ~ variable) %>%  
  ggplot(., aes(x = Wind_mean_Spring, y = log(Recruitment))) +
  geom_text(aes(label = Year))
